import React, { useState } from 'react';
import { X, Printer } from 'lucide-react';
import type { BulletinType } from '../types';
import { useSettings } from '../hooks/useSettings';

interface BulletinPreviewProps {
  etudiant: Etudiant;
  cours: Cours[];
  notes: Note[];
  enseignants: Enseignant[];
  onClose: () => void;
}

export function BulletinPreview({ etudiant, cours, notes, enseignants, onClose }: BulletinPreviewProps) {
  const [bulletinType, setBulletinType] = useState<BulletinType>('semestre1');
  const [remarquesDirecteur, setRemarquesDirecteur] = useState('');
  const [settings] = useSettings();

  const etudiantNotes = notes.filter(note => note.etudiantId === etudiant.id);
  
  const getEnseignantNom = (enseignantId: string) => {
    const enseignant = enseignants.find(e => e.id === enseignantId);
    return enseignant ? `${enseignant.prenom} ${enseignant.nom}` : 'Non assigné';
  };

  const calculerMoyenne = (semestre: 1 | 2, examensFinaux: boolean = false) => {
    const semestreNotes = etudiantNotes.filter(note => {
      const coursInfo = cours.find(c => c.id === note.coursId);
      return note.semestre === semestre && 
             (examensFinaux ? coursInfo?.isExamenFinal : !coursInfo?.isExamenFinal);
    });

    if (semestreNotes.length === 0) return 0;

    let totalPoints = 0;
    let totalCoefficients = 0;

    semestreNotes.forEach(note => {
      const coursInfo = cours.find(c => c.id === note.coursId);
      if (coursInfo) {
        totalPoints += note.valeur * coursInfo.coefficient;
        totalCoefficients += coursInfo.coefficient;
      }
    });

    return totalCoefficients > 0 ? +(totalPoints / totalCoefficients).toFixed(2) : 0;
  };

  const moyenne1 = calculerMoyenne(1);
  const moyenne2 = calculerMoyenne(2);
  const moyenneFinale = calculerMoyenne(bulletinType === 'semestre1' ? 1 : 2, true);
  const moyenneAnnuelle = bulletinType === 'final' 
    ? moyenneFinale 
    : bulletinType === 'semestre1' 
      ? moyenne1 
      : moyenne2;

  const getAppreciationGenerale = (moyenne: number) => {
    if (moyenne >= 16) return 'Excellent';
    if (moyenne >= 14) return 'Très Bien';
    if (moyenne >= 12) return 'Bien';
    if (moyenne >= 10) return 'Assez Bien';
    return 'Insuffisant';
  };

  const handlePrint = () => {
    window.print();
  };

  const filteredCours = cours.filter(c => 
    bulletinType === 'final' ? c.isExamenFinal : !c.isExamenFinal
  );

  const getAnneeAcademique = () => {
    const debut = new Date(settings.anneeAcademique.debut);
    const fin = new Date(settings.anneeAcademique.fin);
    return `${debut.getFullYear()}-${fin.getFullYear()}`;
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg shadow-xl max-w-5xl w-full p-8 max-h-[90vh] overflow-y-auto" id="bulletin-content">
        {/* Type de bulletin */}
        <div className="flex justify-end mb-4 print:hidden">
          <div className="inline-flex rounded-md shadow-sm">
            <button
              onClick={() => setBulletinType('semestre1')}
              className={`px-4 py-2 text-sm font-medium rounded-l-md border ${
                bulletinType === 'semestre1'
                  ? 'bg-green-600 text-white border-green-600'
                  : 'bg-white text-gray-700 border-gray-300 hover:bg-gray-50'
              }`}
            >
              1er Semestre
            </button>
            <button
              onClick={() => setBulletinType('semestre2')}
              className={`px-4 py-2 text-sm font-medium border-t border-b ${
                bulletinType === 'semestre2'
                  ? 'bg-green-600 text-white border-green-600'
                  : 'bg-white text-gray-700 border-gray-300 hover:bg-gray-50'
              }`}
            >
              2ème Semestre
            </button>
            <button
              onClick={() => setBulletinType('final')}
              className={`px-4 py-2 text-sm font-medium rounded-r-md border ${
                bulletinType === 'final'
                  ? 'bg-green-600 text-white border-green-600'
                  : 'bg-white text-gray-700 border-gray-300 hover:bg-gray-50'
              }`}
            >
              Examen Final
            </button>
          </div>
        </div>

        {/* En-tête */}
        <div className="flex justify-between items-start mb-8">
          <div className="text-center flex-1">
            <h2 className="text-2xl font-bold text-green-700">{settings.institut.nom}</h2>
            <p className="text-lg font-semibold">IBACY - Yamoussoukro</p>
            <p className="text-gray-600 mt-2">{settings.institut.adresse}</p>
            <p className="text-gray-600">Tél: {settings.institut.telephone}</p>
            <h3 className="text-xl font-bold mt-4">
              {bulletinType === 'final' 
                ? 'RELEVÉ DE NOTES - EXAMEN FINAL'
                : `BULLETIN DE NOTES - ${bulletinType === 'semestre1' ? '1er' : '2ème'} SEMESTRE`
              }
            </h3>
            <p className="text-gray-600">Année Académique {getAnneeAcademique()}</p>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-full print:hidden"
          >
            <X className="w-6 h-6 text-gray-500" />
          </button>
        </div>

        {/* Informations de l'étudiant */}
        <div className="mb-8 border-t border-b border-gray-200 py-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <p className="text-gray-600">Nom et Prénoms:</p>
              <p className="font-medium text-lg">{etudiant.prenom} {etudiant.nom}</p>
            </div>
            <div>
              <p className="text-gray-600">Classe:</p>
              <p className="font-medium text-lg">{etudiant.classe}ème année</p>
            </div>
          </div>
        </div>

        {/* Relevé de notes */}
        <div className="mb-8">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Matière</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Enseignant</th>
                <th className="px-4 py-3 text-center text-xs font-medium text-gray-500 uppercase">Coef</th>
                <th className="px-4 py-3 text-center text-xs font-medium text-gray-500 uppercase">Note/20</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Appréciation</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {etudiantNotes
                .filter(note => {
                  const coursInfo = cours.find(c => c.id === note.coursId);
                  return note.semestre === (bulletinType === 'semestre1' ? 1 : 2) &&
                         (bulletinType === 'final' ? coursInfo?.isExamenFinal : !coursInfo?.isExamenFinal);
                })
                .map((note) => {
                  const coursInfo = filteredCours.find(c => c.id === note.coursId);
                  return coursInfo ? (
                    <tr key={note.id}>
                      <td className="px-4 py-3">
                        <div>
                          <div className="font-medium text-gray-900">{coursInfo.nom}</div>
                          <div className="text-sm text-gray-500">{coursInfo.matiereNom}</div>
                        </div>
                      </td>
                      <td className="px-4 py-3 text-sm text-gray-500">
                        {getEnseignantNom(coursInfo.enseignantId)}
                      </td>
                      <td className="px-4 py-3 text-center text-sm text-gray-500">
                        {coursInfo.coefficient}
                      </td>
                      <td className="px-4 py-3 text-center font-medium">
                        {note.valeur}
                      </td>
                      <td className="px-4 py-3 text-sm text-gray-600 italic">
                        {note.appreciation || '-'}
                      </td>
                    </tr>
                  ) : null;
                })}
            </tbody>
            <tfoot className="bg-gray-50">
              <tr>
                <td colSpan={3} className="px-4 py-3 text-right font-medium">
                  {bulletinType === 'final' ? 'Moyenne finale:' : 'Moyenne du semestre:'}
                </td>
                <td className="px-4 py-3 text-center font-bold">
                  {moyenneAnnuelle}/20
                </td>
                <td className="px-4 py-3 font-medium text-gray-700">
                  {getAppreciationGenerale(moyenneAnnuelle)}
                </td>
              </tr>
            </tfoot>
          </table>
        </div>

        {/* Remarques du Directeur Académique */}
        <div className="mb-8">
          <h4 className="text-lg font-medium mb-3">Remarques du {settings.directeurs.academique.titre}</h4>
          <textarea
            value={remarquesDirecteur}
            onChange={(e) => setRemarquesDirecteur(e.target.value)}
            className="w-full p-3 border border-gray-300 rounded-md print:border-none print:p-0"
            rows={3}
            placeholder="Ajouter des remarques..."
          />
        </div>

        {/* Signatures */}
        <div className="grid grid-cols-2 gap-8 mt-12 print:mt-16">
          <div className="text-center">
            <p className="font-medium">{settings.directeurs.academique.titre}</p>
            <p className="mt-1">{settings.directeurs.academique.nom}</p>
            <div className="mt-8 h-16 border-b border-gray-300">
              {/* Espace pour la signature */}
            </div>
          </div>
          <div className="text-center">
            <p className="font-medium">{settings.directeurs.general.titre}</p>
            <p className="mt-1">{settings.directeurs.general.nom}</p>
            <div className="mt-8 h-16 border-b border-gray-300">
              {/* Espace pour la signature */}
            </div>
          </div>
        </div>

        {/* Bouton d'impression */}
        <div className="mt-8 flex justify-end print:hidden">
          <button
            onClick={handlePrint}
            className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-green-600 hover:bg-green-700"
          >
            <Printer className="w-4 h-4 mr-2" />
            Imprimer le bulletin
          </button>
        </div>
      </div>
    </div>
  );
}