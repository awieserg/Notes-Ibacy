export interface Etudiant {
  id: string;
  nom: string;
  prenom: string;
  classe: string;
  dateNaissance: string;
}

export interface Enseignant {
  id: string;
  nom: string;
  prenom: string;
  coursIds: string[];
}

export interface Cours {
  id: string;
  nom: string;
  description: string;
  matiereNom: string;
  coefficient: number;
  heures?: number;
  enseignantId: string;
  isExamenFinal?: boolean;
}

export interface Note {
  id: string;
  etudiantId: string;
  coursId: string;
  valeur: number;
  semestre: 1 | 2;
  appreciation?: string;
}

export type BulletinType = 'semestre1' | 'semestre2' | 'final';